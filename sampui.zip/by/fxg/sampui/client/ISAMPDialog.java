package by.fxg.sampui.client;

public interface ISAMPDialog<T> {
	T addCallback(ISAMPCallback callback);
}
